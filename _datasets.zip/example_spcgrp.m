(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
{{{"C", "Diamond"}, "cF8", "A4", "Fd3m", 227, {{0, a/2, a/2}, {a/2, 0, a/2}, 
   {a/2, a/2, 0}}, {{{-a/8, -a/8, -a/8}, "C"}, {{a/8, a/8, a/8}, "C"}}, 
  {a -> 355}}}
